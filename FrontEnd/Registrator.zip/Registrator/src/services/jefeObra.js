// src/services/jefeObraService.js
import axios from "axios";
axios.defaults.withCredentials = true; 

const API = "http://localhost:8080/api/jefeobra";

export const getPendientesJefe = async () => {
  const { data } = await axios.get(`${API}/pendientes`, { withCredentials: true });
  return data || [];
};

/**
 * fecha: string "YYYY-MM-DD"
 * frenteId: number
 * payload: { jefeCedula: string, jefeNombreCompleto: string }
 */
export const aprobarPaquete = async (fecha, frenteId, payload) => {
  const { data } = await axios.put(`${API}/aprobar/${fecha}/${frenteId}`, payload, {
    withCredentials: true,
  });
  return data;
};
