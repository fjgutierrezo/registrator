import React, { useState } from "react";

function ValidacionJefeObra() {
  const [filtro, setFiltro] = useState("Pendiente");
  const [expandido, setExpandido] = useState(null);

  // Estado local con todos los registros (sin filtrarlos aún)
  const [registros, setRegistros] = useState([
    {
      id: 1,
      fecha: "2025-06-07",
      centroCosto: "Cimentación",
      frente: "Frente A",
      estado: "Pendiente",
      detalles: [
        { nombre: "Carlos Pérez", horaIngreso: "07:30", horaSalida: "17:00" },
        { nombre: "María Gómez", horaIngreso: "07:45", horaSalida: "17:10" },
      ],
    },
    {
      id: 2,
      fecha: "2025-06-07",
      centroCosto: "Cimentación",
      frente: "Frente B",
      estado: "Validado",
      detalles: [
        { nombre: "Luis Torres", horaIngreso: "07:35", horaSalida: "17:05" },
      ],
    },
    {
      id: 3,
      fecha: "2025-06-08",
      centroCosto: "Estructura",
      frente: "Frente C",
      estado: "Pendiente",
      detalles: [
        { nombre: "Ana Ruiz", horaIngreso: "07:30", horaSalida: "17:00" },
      ],
    },
  ]);

  // Devuelve solo los registros según el estado actual del filtro
  const registrosFiltrados = registros.filter((r) => r.estado === filtro);

  // Cambia el filtro visual (Pendiente o Validado)
  const cambiarFiltro = (nuevo) => {
    setFiltro(nuevo);
    setExpandido(null);
  };

  // Alternar fila desplegada
  const alternarExpandido = (id) => {
    setExpandido((actual) => (actual === id ? null : id));
  };

  // Alternar validación de un registro
  const alternarValidacion = (id) => {
    const nuevos = registros.map((r) =>
      r.id === id
        ? {
            ...r,
            estado: r.estado === "Pendiente" ? "Validado" : "Pendiente",
          }
        : r
    );

    setRegistros(nuevos);

    // Después de cambiar el estado, contrae todo y permanece en la vista actual
    setExpandido(null);
  };

  return (
    <div style={styles.container}>
      <h2>VALIDACIÓN JEFE DE OBRA</h2>

      {/* Filtro superior */}
      <div style={styles.filtros}>
        <button onClick={() => cambiarFiltro("Pendiente")} style={filtro === "Pendiente" ? styles.botonActivo : null}>
          Pendientes
        </button>
        <button onClick={() => cambiarFiltro("Validado")} style={filtro === "Validado" ? styles.botonActivo : null}>
          Validados
        </button>
      </div>

      {/* Tabla principal */}
      <table style={styles.tabla}>
        <thead>
          <tr>
            <th>Fecha</th>
            <th>Centro de Costo</th>
            <th>Frente de Trabajo</th>
            <th>Estado</th>
            <th>Acción</th>
          </tr>
        </thead>
        <tbody>
          {registrosFiltrados.map((registro) => (
            <React.Fragment key={registro.id}>
              {/* Fila principal con resumen */}
              <tr
                onClick={() => alternarExpandido(registro.id)}
                style={{ cursor: "pointer", backgroundColor: expandido === registro.id ? "#f0f0f0" : "white" }}
              >
                <td>{registro.fecha}</td>
                <td>{registro.centroCosto}</td>
                <td>{registro.frente}</td>
                <td>{registro.estado}</td>
                <td>
                  {/* Detenemos propagación para que no se despliegue al hacer clic en botón */}
                  <button onClick={(e) => { e.stopPropagation(); alternarValidacion(registro.id); }}>
                    {registro.estado === "Pendiente" ? "Validar" : "Quitar validación"}
                  </button>
                </td>
              </tr>

              {/* Fila expandida con detalles de trabajadores */}
              {expandido === registro.id && (
                <tr>
                  <td colSpan="5">
                    <table style={styles.subtabla}>
                      <thead>
                        <tr>
                          <th>Trabajador</th>
                          <th>Hora Ingreso</th>
                          <th>Hora Salida</th>
                        </tr>
                      </thead>
                      <tbody>
                        {registro.detalles.map((d, i) => (
                          <tr key={i}>
                            <td>{d.nombre}</td>
                            <td>{d.horaIngreso}</td>
                            <td>{d.horaSalida}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </td>
                </tr>
              )}
            </React.Fragment>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// Estilos visuales básicos
const styles = {
  container: {
    maxWidth: "900px",
    margin: "0 auto",
    padding: "1rem",
  },
  filtros: {
    marginBottom: "1rem",
    display: "flex",
    gap: "1rem",
  },
  botonActivo: {
    fontWeight: "bold",
    backgroundColor: "#cce5ff",
  },
  tabla: {
    width: "100%",
    borderCollapse: "collapse",
  },
  subtabla: {
    width: "100%",
    marginTop: "0.5rem",
    border: "1px solid #ccc",
  },
};

export default ValidacionJefeObra;
