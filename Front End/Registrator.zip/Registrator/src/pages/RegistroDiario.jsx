// Importamos React, useState para manejar los datos y useEffect para que el componente haga cosas al cargarse
import React, { useState, useEffect } from "react";

function RegistroDiario() {
  // Estado para guardar la fecha y hora actuales
  const [fecha, setFecha] = useState("");
  const [hora, setHora] = useState("");

  // Estado para manejar el archivo adjunto
  const [archivo, setArchivo] = useState(null);
  const [nombreArchivo, setNombreArchivo] = useState("");
  const [categoria, setCategoria] = useState("");

  // Estado para el mensaje de confirmación
  const [mensaje, setMensaje] = useState("");

  // Simulamos los datos del trabajador (luego los tomarás del login)
  const trabajador = {
    nombre: "Nombre",
    apellido: "Apellido"
  };

  // Al cargar el componente, obtenemos la fecha y hora actuales
  useEffect(() => {
    const now = new Date();
    const fechaHoy = now.toLocaleDateString("es-CO"); // ejemplo: 7/6/2025
    const horaActual = now.toLocaleTimeString("es-CO", { hour: "2-digit", minute: "2-digit" }); // ejemplo: 14:32

    setFecha(fechaHoy);
    setHora(horaActual);
  }, []);

  // Maneja el cambio de archivo seleccionado
  const handleFileChange = (e) => {
    const file = e.target.files[0]; // Tomamos el primer archivo
    setArchivo(file);               // Lo guardamos en el estado
    setNombreArchivo(file ? file.name : "");
  };

  // Función que se ejecuta al hacer clic en REGISTRAR
  const handleRegistro = (e) => {
    e.preventDefault();

    // Validamos que se haya seleccionado una categoría si hay archivo
    if (archivo && !categoria) {
      alert("Debes seleccionar una categoría para el archivo");
      return;
    }

    // Simulamos el envío de datos
    console.log("Registro enviado:", {
      fecha,
      hora,
      archivo,
      categoria,
    });

    // Mostramos el mensaje de confirmación personalizado
    setMensaje(
      `${trabajador.nombre} ${trabajador.apellido} ingresó con éxito a las ${hora} el día ${fecha}`
    );

    // Ocultamos el mensaje después de 5 segundos
    setTimeout(() => setMensaje(""), 5000);
  };

  return (
    <div style={styles.container}>
      <h2>REGISTRO DIARIO</h2>

      <form onSubmit={handleRegistro} style={styles.form}>
        {/* Mostramos fecha y hora actuales en campos desactivados */}
        <input type="text" value={fecha} readOnly />
        <input type="text" value={hora} readOnly />

        {/* Botón para registrar la asistencia */}
        <button type="submit">REGISTRAR</button>

        {/* Sección para subir un archivo opcional */}
        <div>
          <label>Adjuntar Archivos:</label><br />
          <input type="file" onChange={handleFileChange} />

          {/* Mostramos el nombre del archivo cargado */}
          {nombreArchivo && <p>Nombre archivo: {nombreArchivo}</p>}

          {/* Categoría del documento */}
          <select value={categoria} onChange={(e) => setCategoria(e.target.value)}>
            <option value="">Selecciona Categoría</option>
            <option value="documento">Documento</option>
            <option value="permiso">Permiso</option>
            <option value="incapacidad">Incapacidad</option>
          </select>
        </div>
      </form>

      {/* Mensaje de confirmación visible solo si hay texto */}
      {mensaje && <p style={styles.mensaje}>{mensaje}</p>}
    </div>
  );
}

// Estilos sencillos para mantener el diseño ordenado
const styles = {
  container: {
    maxWidth: "500px",
    margin: "0 auto",
    padding: "1rem",
  },
  form: {
    display: "flex",
    flexDirection: "column",
    gap: "10px",
  },
  mensaje: {
    marginTop: "20px",
    backgroundColor: "#d4edda",
    padding: "10px",
    border: "1px solid #28a745",
    borderRadius: "5px",
    color: "#155724",
    fontWeight: "bold",
  },
};

export default RegistroDiario;
