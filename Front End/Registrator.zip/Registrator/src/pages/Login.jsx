import React, { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../utils/AuthContext";

function Login() {
  // Guardamos el perfil y usuario que elige el usuario
  const [perfil, setPerfil] = useState("");
  const [usuario, setUsuario] = useState("");
  const [password, setPassword] = useState(""); // Simulado

  // Hook para redirigir a otra ruta
  const navigate = useNavigate();

  // Obtenemos la función de login desde el contexto
  const { login } = useContext(AuthContext);

  // Cuando se envía el formulario
  const handleSubmit = (e) => {
    e.preventDefault();

    // Guardamos perfil y usuario globalmente
    login(perfil, usuario);

    // Redireccionamos según el perfil elegido
    switch (perfil) {
      case "trabajador":
        navigate("/registro-diario");
        break;
      case "capataz":
        navigate("/control-diario");
        break;
      case "jefe":
        navigate("/validacion-jefe");
        break;
      case "rrhh":
        navigate("/nomina");
        break;
      default:
        alert("Perfil no válido");
    }
  };

  return (
    <div style={styles.container}>
      <h2>Bienvenido a Registrator</h2>
      <form onSubmit={handleSubmit} style={styles.form}>
        <label>Perfil:</label>
        <select
          value={perfil}
          onChange={(e) => setPerfil(e.target.value)}
          required
        >
          <option value="">-- Seleccionar --</option>
          <option value="trabajador">Trabajador</option>
          <option value="capataz">Capataz</option>
          <option value="jefe">Jefe de Obra</option>
          <option value="rrhh">Recursos Humanos</option>
        </select>

        <label>Usuario:</label>
        <input
          type="text"
          value={usuario}
          onChange={(e) => setUsuario(e.target.value)}
          required
        />

        <label>Contraseña:</label>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />

        <button type="submit">Ingresar</button>
      </form>
    </div>
  );
}

// Estilos simples en línea
const styles = {
  container: {
    maxWidth: "400px",
    margin: "0 auto",
    padding: "2rem",
    fontFamily: "Arial",
  },
  form: {
    display: "flex",
    flexDirection: "column",
    gap: "1rem",
  },
};

export default Login;
