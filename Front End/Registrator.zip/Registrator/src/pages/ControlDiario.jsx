import React, { useState, useEffect } from "react";

function ControlDiario() {
  const [fechaSeleccionada, setFechaSeleccionada] = useState("");
  const [registros, setRegistros] = useState([]);
  const [mensaje, setMensaje] = useState("");

  // Cargar registros simulados al iniciar
  useEffect(() => {
    const registrosFicticios = [
      {
        id: 1,
        nombre: "Carlos Pérez",
        entrada: "07:30",
        salida: "17:00",
        frenteObra: "Excavación",
        estado: "Pendiente",
      },
      {
        id: 2,
        nombre: "Laura Rodríguez",
        entrada: "07:45",
        salida: "17:05",
        frenteObra: "Estructura",
        estado: "Validado",
      },
    ];
    setRegistros(registrosFicticios);
  }, []);

  // Validar o quitar validación
  const toggleValidacion = (id) => {
    const nuevosRegistros = registros.map((registro) =>
      registro.id === id
        ? {
            ...registro,
            estado: registro.estado === "Pendiente" ? "Validado" : "Pendiente",
          }
        : registro
    );
    setRegistros(nuevosRegistros);
    setMensaje("Validación actualizada");

    setTimeout(() => setMensaje(""), 3000);
  };

  // Actualiza cualquier campo editable (hora entrada, salida, frente de obra)
  const editarCampo = (id, campo, valor) => {
    const nuevosRegistros = registros.map((registro) =>
      registro.id === id ? { ...registro, [campo]: valor } : registro
    );
    setRegistros(nuevosRegistros);
  };

  // Cambia la fecha del filtro (por ahora visual)
  const handleFechaChange = (e) => {
    setFechaSeleccionada(e.target.value);
  };

  return (
    <div style={styles.container}>
      <h2>CONTROL DIARIO</h2>

      {/* Fecha seleccionada */}
      <div style={styles.filaFecha}>
        <label>Selecciona una fecha:</label>
        <input type="date" value={fechaSeleccionada} onChange={handleFechaChange} />
      </div>

      {/* Tabla de registros */}
      <table style={styles.tabla}>
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Hora Ingreso</th>
            <th>Hora Salida</th>
            <th>Frente de Obra</th>
            <th>Estado</th>
            <th>Acción</th>
          </tr>
        </thead>
        <tbody>
          {registros.map((registro) => (
            <tr key={registro.id}>
              <td>{registro.nombre}</td>

              {/* Hora de entrada editable */}
              <td>
                <input
                  type="time"
                  value={registro.entrada}
                  onChange={(e) => editarCampo(registro.id, "entrada", e.target.value)}
                />
              </td>

              {/* Hora de salida editable */}
              <td>
                <input
                  type="time"
                  value={registro.salida}
                  onChange={(e) => editarCampo(registro.id, "salida", e.target.value)}
                />
              </td>

              {/* Frente de obra editable */}
              <td>
                <select
                  value={registro.frenteObra}
                  onChange={(e) => editarCampo(registro.id, "frenteObra", e.target.value)}
                >
                  <option value="Excavación">Excavación</option>
                  <option value="Estructura">Estructura</option>
                  <option value="Acabados">Acabados</option>
                  <option value="Electricidad">Electricidad</option>
                  <option value="Plomería">Plomería</option>
                </select>
              </td>

              {/* Estado actual */}
              <td>{registro.estado}</td>

              {/* Botón para validar o desvalidar */}
              <td>
                <button onClick={() => toggleValidacion(registro.id)}>
                  {registro.estado === "Pendiente" ? "Validar" : "Quitar validación"}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Mensaje de acción */}
      {mensaje && <p style={styles.mensaje}>{mensaje}</p>}
    </div>
  );
}

// Estilos CSS en JS
const styles = {
  container: {
    maxWidth: "900px",
    margin: "0 auto",
    padding: "1rem",
  },
  filaFecha: {
    marginBottom: "1rem",
  },
  tabla: {
    width: "100%",
    borderCollapse: "collapse",
  },
  mensaje: {
    marginTop: "1rem",
    padding: "10px",
    backgroundColor: "#d4edda",
    border: "1px solid #28a745",
    borderRadius: "5px",
    color: "#155724",
  },
};

export default ControlDiario;
