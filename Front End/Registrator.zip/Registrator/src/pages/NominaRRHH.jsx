import React, { useState, useEffect } from "react";

function NominaRRHH() {
  const [fechaInicio, setFechaInicio] = useState("");
  const [fechaFin, setFechaFin] = useState("");
  const [expandido, setExpandido] = useState(null);

  // Registros simulados con centro de costo y horas
  const [registros, setRegistros] = useState([]);

  useEffect(() => {
    const datosSimulados = [
      {
        id: 1,
        nombre: "Carlos Pérez",
        valorHora: 12000,
        registros: [
          { fecha: "2025-06-01", horas: 8, centro: "Cimentación", entrada: "07:30", salida: "17:00" },
          { fecha: "2025-06-02", horas: 7.5, centro: "Cimentación", entrada: "07:45", salida: "15:15" },
          { fecha: "2025-06-03", horas: 8, centro: "Estructura", entrada: "07:30", salida: "17:00" },
        ],
      },
      {
        id: 2,
        nombre: "Laura Gómez",
        valorHora: 13000,
        registros: [
          { fecha: "2025-06-01", horas: 8, centro: "Acabados", entrada: "07:50", salida: "17:30" },
          { fecha: "2025-06-03", horas: 6, centro: "Acabados", entrada: "08:00", salida: "14:00" },
        ],
      },
    ];
    setRegistros(datosSimulados);
  }, []);

  const actualizarValorHora = (id, nuevoValor) => {
    const nuevos = registros.map((r) =>
      r.id === id ? { ...r, valorHora: Number(nuevoValor) } : r
    );
    setRegistros(nuevos);
  };

  const calcularSubtotal = (trabajador) => {
    const horasTotales = trabajador.registros.reduce((sum, r) => sum + r.horas, 0);
    return horasTotales * trabajador.valorHora;
  };

  const totalGeneral = registros.reduce(
    (sum, t) => sum + calcularSubtotal(t),
    0
  );

  const alternarExpandido = (id) => {
    setExpandido((actual) => (actual === id ? null : id));
  };

  return (
    <div style={styles.container}>
      <h2>NÓMINA - RECURSOS HUMANOS</h2>

      <div style={styles.filtros}>
        <label>Desde:</label>
        <input type="date" value={fechaInicio} onChange={(e) => setFechaInicio(e.target.value)} />
        <label>Hasta:</label>
        <input type="date" value={fechaFin} onChange={(e) => setFechaFin(e.target.value)} />
      </div>

      <table style={styles.tabla}>
        <thead>
          <tr>
            <th>Trabajador</th>
            <th>Días</th>
            <th>Horas</th>
            <th>Valor Hora</th>
            <th>Subtotal</th>
          </tr>
        </thead>
        <tbody>
          {registros.map((t) => {
            const horasTotales = t.registros.reduce((sum, r) => sum + r.horas, 0);
            return (
              <React.Fragment key={t.id}>
                <tr>
                  {/* Hacer clic en el nombre despliega el detalle */}
                  <td style={{ cursor: "pointer", color: "blue" }} onClick={() => alternarExpandido(t.id)}>
                    {t.nombre}
                  </td>
                  <td>{t.registros.length}</td>
                  <td>{horasTotales}</td>
                  <td>
                    <input
                      type="number"
                      value={t.valorHora}
                      onChange={(e) => actualizarValorHora(t.id, e.target.value)}
                    />
                  </td>
                  <td>{calcularSubtotal(t)}</td>
                </tr>

                {/* Detalle desplegable si está expandido */}
                {expandido === t.id && (
                  <tr>
                    <td colSpan="5">
                      <table style={styles.subtabla}>
                        <thead>
                          <tr>
                            <th>Fecha</th>
                            <th>Centro de Costo</th>
                            <th>Hora Ingreso</th>
                            <th>Hora Salida</th>
                            <th>Horas</th>
                          </tr>
                        </thead>
                        <tbody>
                          {t.registros.map((r, i) => (
                            <tr key={i}>
                              <td>{r.fecha}</td>
                              <td>{r.centro}</td>
                              <td>{r.entrada}</td>
                              <td>{r.salida}</td>
                              <td>{r.horas}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </td>
                  </tr>
                )}
              </React.Fragment>
            );
          })}
        </tbody>
        <tfoot>
          <tr>
            <td colSpan="4" style={{ textAlign: "right", fontWeight: "bold" }}>TOTAL GENERAL:</td>
            <td style={{ fontWeight: "bold" }}>{totalGeneral}</td>
          </tr>
        </tfoot>
      </table>

      <button style={styles.botonExportar} onClick={() => alert("Exportar nómina (simulado)")}>
        Exportar Nómina
      </button>
    </div>
  );
}

const styles = {
  container: {
    maxWidth: "1000px",
    margin: "0 auto",
    padding: "1rem",
  },
  filtros: {
    display: "flex",
    gap: "1rem",
    marginBottom: "1rem",
  },
  tabla: {
    width: "100%",
    borderCollapse: "collapse",
  },
  subtabla: {
    width: "100%",
    border: "1px solid #ccc",
    marginTop: "0.5rem",
  },
  botonExportar: {
    marginTop: "1rem",
    padding: "10px",
    backgroundColor: "#007bff",
    color: "white",
    border: "none",
    borderRadius: "5px",
  },
};

export default NominaRRHH;
