// Importamos React y el hook useState para manejar el estado del formulario
import React, { useState } from "react";

function RegistroEmpleado() {
  // Estado que guarda todos los campos del formulario en un objeto
  const [formData, setFormData] = useState({
    nombres: "",
    apellidos: "",
    direccion: "",
    fechaNacimiento: "",
    area: "",
    cargo: "",
    salario: "",
    email: "",
    usuario: "",
    password: "",
    perfil: "",
  });

  // Estado para controlar si se muestra el mensaje de "MENSAJE ENVIADO"
  const [mensajeEnviado, setMensajeEnviado] = useState(false);

  // Función que se ejecuta cuando cambia un campo del formulario
  const handleChange = (e) => {
    const { name, value } = e.target; // Extraemos el nombre del campo y su nuevo valor

    // Actualizamos el estado formData con el nuevo valor del campo correspondiente
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  // Función que se ejecuta al enviar el formulario
  const handleSubmit = (e) => {
    e.preventDefault(); // Evita que se recargue la página

    // Mostramos en consola los datos del empleado (esto luego se conectará al backend)
    console.log("Empleado registrado:", formData);

    // Mostramos el mensaje de éxito
    setMensajeEnviado(true);

    // Ocultamos el mensaje después de 3 segundos
    setTimeout(() => setMensajeEnviado(false), 3000);
  };

  return (
    <div style={styles.container}>
      <h2>REGISTRO DE EMPLEADO</h2>

      {/* Formulario con todos los campos necesarios */}
      <form onSubmit={handleSubmit} style={styles.form}>
        {/* Cada input tiene un 'name' que debe coincidir con una propiedad en formData */}
        <input type="text" name="nombres" placeholder="Nombres" onChange={handleChange} required />
        <input type="text" name="apellidos" placeholder="Apellidos" onChange={handleChange} required />
        <input type="text" name="direccion" placeholder="Dirección" onChange={handleChange} required />
        <input type="date" name="fechaNacimiento" onChange={handleChange} required />
        <input type="text" name="area" placeholder="Área" onChange={handleChange} required />
        <input type="text" name="cargo" placeholder="Cargo" onChange={handleChange} required />
        <input type="number" name="salario" placeholder="Salario" onChange={handleChange} required />
        <input type="email" name="email" placeholder="Email" onChange={handleChange} required />
        <input type="text" name="usuario" placeholder="Usuario" onChange={handleChange} required />
        <input type="password" name="password" placeholder="Contraseña" onChange={handleChange} required />

        {/* Lista desplegable para seleccionar el perfil */}
        <select name="perfil" onChange={handleChange} required>
          <option value="">Selecciona perfil</option>
          <option value="trabajador">Trabajador</option>
          <option value="capataz">Capataz</option>
          <option value="jefe">Jefe de obra</option>
        </select>

        {/* Botón que envía el formulario */}
        <button type="submit">GUARDAR</button>
      </form>

      {/* Mensaje que se muestra después de enviar el formulario */}
      {mensajeEnviado && <p style={styles.mensaje}>MENSAJE ENVIADO</p>}
    </div>
  );
}

// Estilos básicos para la vista, escritos como un objeto JavaScript
const styles = {
  container: {
    maxWidth: "500px",        // Ancho máximo del contenedor
    margin: "0 auto",         // Centrado horizontal
    padding: "1rem",          // Espaciado interior
  },
  form: {
    display: "flex",          // Organización en columnas
    flexDirection: "column",
    gap: "10px",              // Espacio entre campos
  },
  mensaje: {
    marginTop: "20px",
    color: "green",
    fontWeight: "bold",
  },
};

export default RegistroEmpleado;
