import React, { useContext } from "react";
import { AuthContext } from "./utils/AuthContext";

function TestContext() {
  // Extraemos las funciones y estado del contexto global
  const { perfil, usuario, login, logout } = useContext(AuthContext);

  return (
    <div style={styles.container}>
      <h2>🧪 Prueba de múltiples roles desde el contexto</h2>

      <div style={styles.info}>
        <p><strong>Perfil actual:</strong> {perfil || "Ninguno"}</p>
        <p><strong>Usuario actual:</strong> {usuario || "Anónimo"}</p>
      </div>

      <div style={styles.buttons}>
        <button onClick={() => login("rrhh", "Laura RH")}>Login como RRHH</button>
        <button onClick={() => login("capataz", "Carlos Capataz")}>Login como Capataz</button>
        <button onClick={() => login("jefe", "Andrés Jefe")}>Login como Jefe de Obra</button>
        <button onClick={() => login("trabajador", "Pedro Trabajador")}>Login como Trabajador</button>
        <button onClick={logout} style={{ backgroundColor: "red", color: "white" }}>
          Cerrar sesión
        </button>
      </div>
    </div>
  );
}

const styles = {
  container: {
    padding: "2rem",
    fontFamily: "Arial",
  },
  info: {
    marginBottom: "1.5rem",
    fontSize: "1.1rem",
  },
  buttons: {
    display: "flex",
    flexDirection: "column",
    gap: "0.5rem",
    maxWidth: "250px",
  },
};

export default TestContext;
