import { AuthContext } from "./AuthContext";

export const AuthProvider = ({ children }) => {
  // ...
  return (
    <AuthContext.Provider value={{ perfil, usuario, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
