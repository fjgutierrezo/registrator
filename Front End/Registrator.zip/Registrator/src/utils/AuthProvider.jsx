import React, { useState } from "react";
import { AuthContext } from "./AuthContext";

export const AuthProvider = ({ children }) => {
  const [perfil, setPerfil] = useState(null);
  const [usuario, setUsuario] = useState("");

  const login = (nuevoPerfil, nombreUsuario) => {
    setPerfil(nuevoPerfil);
    setUsuario(nombreUsuario);
  };

  const logout = () => {
    setPerfil(null);
    setUsuario("");
  };

  return (
    <AuthContext.Provider value={{ perfil, usuario, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};


