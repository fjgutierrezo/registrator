package com.TMF.registrator.dto;

public class JefeAprobarPaqueteRequest {
    private String jefeCedula;
    private String jefeNombreCompleto;

    public String getJefeCedula() { return jefeCedula; }
    public void setJefeCedula(String v) { this.jefeCedula = v; }

    public String getJefeNombreCompleto() { return jefeNombreCompleto; }
    public void setJefeNombreCompleto(String v) { this.jefeNombreCompleto = v; }
}
