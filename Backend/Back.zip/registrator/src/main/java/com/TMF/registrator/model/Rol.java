package com.TMF.registrator.model;

public enum Rol {
    TRABAJADOR,
    CAPATAZ,
    JEFE_OBRA,
    RRHH
}
