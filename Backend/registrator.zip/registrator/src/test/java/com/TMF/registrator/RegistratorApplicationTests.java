package com.TMF.registrator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
