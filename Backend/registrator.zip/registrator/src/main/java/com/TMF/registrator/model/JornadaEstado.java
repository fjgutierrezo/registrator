package com.TMF.registrator.model;

public enum JornadaEstado {
    ACTIVA, CERRADA
}
