package com.TMF.registrator.model;

public enum AprobacionEstado {
    EN_APROBACION,
    APROBADO_CAPATAZ,
    APROBADO_JEFE,
    RECHAZADO
}
